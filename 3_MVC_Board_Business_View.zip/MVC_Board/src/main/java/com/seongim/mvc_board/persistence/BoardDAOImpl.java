package com.seongim.mvc_board.persistence;

import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.seongim.mvc_board.domain.BoardVO;
import com.seongim.mvc_board.domain.FileVO;
import com.seongim.mvc_board.domain.PagingVO;

@Repository
public class BoardDAOImpl implements BoardDAO {
	
	@Inject
	private SqlSession sqlSession;
	
	private static String namespace = "com.seongim.mvc_board.mapper.BoardMapper";

	@Override
	public void insertBoard(BoardVO boardVO) throws Exception {
		sqlSession.insert(namespace + ".insertBoard", boardVO);
	}

	@Override
	public List<Map<String, Object>> getBoardList(PagingVO pagingVO) throws Exception {
		return sqlSession.selectList(namespace + ".getBoardList", pagingVO);
	}

	@Override
	public Map<String, Object> getBoardDetail(BoardVO boardVO) throws Exception {
		return sqlSession.selectOne(namespace + ".getBoardDetail", boardVO);
	}

	@Override
	public void updateBoard(BoardVO boardVO) throws Exception {
		sqlSession.update(namespace + ".updateBoard", boardVO);
	}

	@Override
	public void deleteBoard(BoardVO boardVO) throws Exception {
		sqlSession.update(namespace + ".deleteBoard", boardVO);
	}
	
	@Override
	public void updateHit(BoardVO boardVO) throws Exception {
		sqlSession.update(namespace + ".updateHit", boardVO);
	}
	
	@Override
	public int getBoardCount() throws Exception {
		return sqlSession.selectOne(namespace + ".getBoardCount");
	}
	
	@Override
	public int getBoardId() throws Exception {
		return sqlSession.selectOne(namespace + ".getBoardId");
	}
	
	@Override
	public void uploadFile(Map<String, Object> map) throws Exception {
		sqlSession.insert(namespace + ".uploadFile", map);
	}
	
	@Override
	public List<Map<String, Object>>getFileList(BoardVO boardVO) throws Exception {
		return sqlSession.selectList(namespace + ".getFileList", boardVO);
	}
	
	@Override
	public void deleteFile(String saveFileName) throws Exception {
		sqlSession.update(namespace + ".deleteFile", saveFileName);
	}


} //BoardDAOImpl
