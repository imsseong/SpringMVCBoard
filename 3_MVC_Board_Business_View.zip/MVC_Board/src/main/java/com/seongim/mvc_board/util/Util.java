package com.seongim.mvc_board.util;

import java.util.HashMap;
import java.util.Map;

public class Util {
	
	public Map<String, Object> successTrue(String msg, Object data) {

		  Map<String, Object> map = new HashMap<String, Object>();
		  
		  map.put("success", true);
		  map.put("message", msg);
		  map.put("error", null);
		  map.put("data", data);
		  
		  return map;
	} //successTrue
	
	public Map<String, Object> successFalse(String msg, Error err) {

		  Map<String, Object> map = new HashMap<String, Object>();
		  
		  map.put("success", true);
		  map.put("message", msg);
		  map.put("error", err);
		  map.put("data", null);
		  
		  return map;
	} //successFalse
		  
} //Util
