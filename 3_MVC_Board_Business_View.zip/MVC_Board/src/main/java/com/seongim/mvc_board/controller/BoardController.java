package com.seongim.mvc_board.controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.annotation.Resource;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.seongim.mvc_board.domain.BoardVO;
import com.seongim.mvc_board.domain.FileVO;
import com.seongim.mvc_board.domain.PagingVO;
import com.seongim.mvc_board.domain.ReplyVO;
import com.seongim.mvc_board.service.BoardService;
import com.seongim.mvc_board.service.ReplyService;
import com.seongim.mvc_board.util.Paging;
import com.seongim.mvc_board.util.Upload;
import com.seongim.mvc_board.util.Util;

@Controller
@RequestMapping("/board")
public class BoardController {
	
	private static final Logger logger = LoggerFactory.getLogger(BoardController.class);
	
	@Inject
	private BoardService boardService;
	@Inject
	private ReplyService replyService;

	@Resource(name="uploadPath")
	private String uploadPath;
	
	/** �Խ��� ��� ��ȸ */
	@RequestMapping(value="/list/{page}", method=RequestMethod.GET)
	@ResponseBody
	public Map<String, Object> getBoardList(@PathVariable int page, HttpServletRequest request, HttpServletResponse response, PagingVO pagingVO) throws Exception {
		Util util = new Util();
		logger.debug("########getPage={}",pagingVO.getPage());
		logger.debug("########getPageStart={}",pagingVO.getPageStart());
		logger.debug("########getPerPageNum={}",pagingVO.getPerPageNum());
		Paging pageMaker = new Paging();
		pagingVO.setPage(page);
		logger.debug("########page={}",pagingVO.getPage());
		pageMaker.setPagingVO(pagingVO);
		pageMaker.setTotalCount(boardService.getBoardCount());
		
		List<Map<String,Object>> board = boardService.getBoardList(pagingVO);
		
		Map<String, Object> data = new HashMap<String, Object>();
		data.put("board", board);
		data.put("total_count", pageMaker.getTotalCount());
		data.put("prev", pageMaker.isPrev());
		data.put("next", pageMaker.isNext());
		data.put("start_page", pageMaker.getStartPage());
		data.put("end_page", pageMaker.getEndPage());
		data.put("page", pagingVO.getPage());
		
		Map<String, Object> output = new HashMap<String, Object>();
		
		output = util.successTrue("getBoardList success!", data);
	
		return output;
	}

	/** �Խ��� ��� */
	@RequestMapping(value="/write", method=RequestMethod.POST)
	@ResponseBody
	public void insertBoard(MultipartHttpServletRequest request
			, @RequestParam String title
			, @RequestParam String writer
			, @RequestParam String content) throws Exception {
		
		BoardVO boardVO = new BoardVO();
		
		boardVO.setTitle(title);
		boardVO.setWriter(writer);
		boardVO.setContent(content);
		
		boardService.insertBoard(boardVO);
		
		Upload upload = new Upload();
		upload.uploadFile(boardService, request);
	}

	/** �Խ��� �� */
	@RequestMapping(value="/detail/{id}", method=RequestMethod.GET)
	@ResponseBody
	public Map<String, Object> boardDetail(@PathVariable("id") int id, ReplyVO replyVO) throws Exception {
		Util util = new Util();
		
		BoardVO boardVO = new BoardVO();
		boardVO.setId(id);
		
	    Map<String, Object> detail = boardService.getBoardDetail(boardVO);
	    List<Map<String,Object>> file = boardService.getFileList(boardVO);
	    List<Map<String,Object>> reply = replyService.getReplyList(boardVO);

	    Map<String, Object> data = new HashMap<String, Object>();
	    
	    data.put("detail", detail);
	    data.put("file", file);
		data.put("reply", reply);
		
		Map<String, Object> output = new HashMap<String, Object>();
		
		output = util.successTrue("getBoardList success!", data);
	    
	    return output;
	}
	
	/** ���� �ٿ�ε� */
	@RequestMapping(value="/detail/file", method=RequestMethod.POST)
	@ResponseBody
	public void downloadFile(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		Upload upload = new Upload();
		upload.downloadFile(request, response);
	}
	
	/** �Խ��� ���� */
	@RequestMapping(value="/update/{id}", method=RequestMethod.POST)
	@ResponseBody
	public void boardUpdatePost(@PathVariable("id") int id
			, @RequestParam String title
			, @RequestParam String writer
			, @RequestParam String content
			, MultipartHttpServletRequest request) throws Exception {
		
		BoardVO boardVO = new BoardVO();
		
		boardVO.setId(id);
		boardVO.setTitle(title);
		boardVO.setWriter(writer);
		boardVO.setContent(content);
		
		boardService.updateBoard(boardVO);
		
		Upload upload = new Upload();
		upload.uploadFile(boardService, request);
	}
	
	/** �Խ��� ���� */
	@RequestMapping(value="/delete/{id}", method=RequestMethod.DELETE)
	@ResponseBody
	public Map<String, Object> boardDelete(@PathVariable int id) throws Exception {
		Util util = new Util();
		
        BoardVO boardVO = new BoardVO();
        boardVO.setId(id);
		boardService.deleteBoard(boardVO);
		
		Map<String, Object> output = new HashMap<String, Object>();
		
		output = util.successTrue("boardDelete success!", null);
		return output;
	}
	
	/** ���� ���� */
	@RequestMapping(value="/delete/file/{save_file_name:.+}", method=RequestMethod.DELETE)
	@ResponseBody
	public void deleteFile(@PathVariable("save_file_name") String save_file_name, HttpServletRequest request) throws Exception {
		
		logger.debug("########save_file_name ={}", save_file_name);
	
		Util util = new Util();
		
		boardService.deleteFile(save_file_name);	
		
	}
	
	/** ��� ��� */
	@RequestMapping(value="/write/reply/{id}", method=RequestMethod.POST)
	@ResponseBody
    public Map<String, Object> replyWrite(@RequestParam String reply_writer
    		, @RequestParam String reply_content
    		, @PathVariable int id) throws Exception {
		
		Util util = new Util();
		ReplyVO replyVO = new ReplyVO();
		
        replyVO.setReply_writer(reply_writer);
        replyVO.setReply_content(reply_content);
        replyVO.setBoard_id(id);
        
        replyService.insertReply(replyVO);
        
        Map<String, Object> output = new HashMap<String, Object>();
		
		output = util.successTrue("replyWrite success!", null);
		return output;
    }
	
	/** ��� ���� */
	@RequestMapping(value="/delete/reply/{reply_id}", method=RequestMethod.DELETE)
	@ResponseBody
	public Map<String, Object> replyDelete(@PathVariable int reply_id) throws Exception {
		Util util = new Util();
		ReplyVO replyVO = new ReplyVO();
		
		replyVO.setReply_id(reply_id);
		
		replyService.deleteReply(replyVO);
        
		Map<String, Object> output = new HashMap<String, Object>();
		
		output = util.successTrue("replyDelete success!", null);
		return output;
	}
	
	
	

	

} //BoardController
