package com.seongim.mvc_board.util;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.seongim.mvc_board.controller.BoardController;
import com.seongim.mvc_board.service.BoardService;

public class Upload {
	private static final Logger logger = LoggerFactory.getLogger(BoardController.class);
	
	public void uploadFile(BoardService boardService, MultipartHttpServletRequest request) {
		
		List<MultipartFile> fileList = request.getFiles("files");
		
		if(request.getFiles("files").get(0).getSize() != 0) {
        	fileList = request.getFiles("files");
        }
		
	    String uploadPath = "C:\\Tomcat\\webapps\\upload";
	    File fileDir = new File(uploadPath);

	    if (!fileDir.isDirectory()) {
	    	fileDir.mkdirs();
	    }
	    
	    if ( fileList != null && fileList.size() > 0 ) {
	    	long time = System.currentTimeMillis();
	    	
	    	for (MultipartFile mf : fileList) {
	        	if ( !mf.isEmpty() ) {
	        		System.out.println(mf.getOriginalFilename() +" uploaded!");
	        		String originFileName = mf.getOriginalFilename();
	        		String originalFileExtension = originFileName.substring(originFileName.lastIndexOf(".")); 
	        		System.out.println(originalFileExtension +" originalFileExtension!");
	        		String saveFileName = String.format("%d_%s", time, originFileName); 
	        		long fileSize = mf.getSize();
	        		
	        		try {
	        			mf.transferTo(new File(uploadPath, saveFileName));
	        			int boardId = boardService.getBoardId();
	        			boardService.uploadFile(boardId, originFileName,saveFileName, fileSize, originalFileExtension);
	        		} catch(Exception e) {
	        			e.printStackTrace();
	        		}
	        	} //if
        	} //for
	    } else {
	    	 System.out.println("ERROR");
	    }
	} //uploadFile
	
	public void downloadFile(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String saveFileName = request.getParameter("saveFileName");
		String originFileName = request.getParameter("originFileName");
		//String originFileName = "a.txt";
	
		logger.debug("########saveFileName ={}", saveFileName);
		logger.debug("########originFileName ={}", originFileName);

		File file = new File("C:\\Tomcat\\webapps\\upload", "a.txt");
		
		if(!file.exists()) {
			logger.debug("########�����������");
		}
		
		//User-Agent : � �ü����  � �������� ����( Ȩ������ )�� �����ϴ��� Ȯ����
		String header = request.getHeader("User-Agent");
		String fileName;
		
		if ((header.contains("MSIE")) || (header.contains("Trident")) || (header.contains("Edge"))) {
			//���ͳ� �ͽ��÷η� 10���� ����, 11����, �������� ���ڵ� 
	        fileName = URLEncoder.encode(originFileName, "UTF-8");
		 } else {
		    //������ ���������� ���ڵ�
		    fileName = new String(originFileName.getBytes("UTF-8"), "iso-8859-1");
		 }
		 
		 //������ �𸣴� ����÷�ο� contentType
		 response.setContentType("application/octet-stream;charset=utf-8");
		 response.setContentLength((int)file.length());

		 //�ٿ�ε�� �ٿ�ε�� �����̸�
		 response.setHeader("Content-Disposition", "attachment; filename=\""+ fileName + "\"");

		 BufferedInputStream in = new BufferedInputStream(new FileInputStream(file));
		 OutputStream out = response.getOutputStream();
		 FileCopyUtils.copy(in, out);
		 
		 in.close();
		 out.flush();
		 //response.getOutputStream().close(); 


	} //downloadFile
	

} //Upload
