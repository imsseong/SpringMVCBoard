package com.seongim.mvc_board.persistence;

import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.seongim.mvc_board.domain.BoardVO;
import com.seongim.mvc_board.domain.ReplyVO;

@Repository
public class ReplyDAOImpl implements ReplyDAO {

	@Inject
	private SqlSession sqlSession;
	
	private static String namespace = "com.seongim.mvc_board.mapper.ReplyMapper";

	@Override
	public void insertReply(ReplyVO replyVO) throws Exception {
		sqlSession.insert(namespace + ".insertReply", replyVO);		
	}

	@Override
	public List<Map<String, Object>> getReplyList(BoardVO boardVO) throws Exception {
		return sqlSession.selectList(namespace + ".getReplyList", boardVO);
	}

	@Override
	public void deleteReply(ReplyVO replyVO) throws Exception {
		sqlSession.update(namespace + ".deleteReply", replyVO);		
	}

	@Override
	public void deleteReplyAll(ReplyVO replyVO) throws Exception {
		sqlSession.update(namespace + ".deleteReplyAll", replyVO);		
	}

} //ReplyDAOImpl
