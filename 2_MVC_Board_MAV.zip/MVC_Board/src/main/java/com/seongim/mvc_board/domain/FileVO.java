package com.seongim.mvc_board.domain;

import java.sql.Timestamp;

public class FileVO {
	private Integer dboard_id;
	private String org_file_name;
	private String save_file_name;
	private Integer file_size;
	private Timestamp reg_date;
	private Timestamp mod_date;
	private String del_flag;
	public Integer getDboard_id() {
		return dboard_id;
	}
	public void setDboard_id(Integer dboard_id) {
		this.dboard_id = dboard_id;
	}
	public String getOrg_file_name() {
		return org_file_name;
	}
	public void setOrg_file_name(String org_file_name) {
		this.org_file_name = org_file_name;
	}
	public String getSave_file_name() {
		return save_file_name;
	}
	public void setSave_file_name(String save_file_name) {
		this.save_file_name = save_file_name;
	}
	public Integer getFile_size() {
		return file_size;
	}
	public void setFile_size(Integer file_size) {
		this.file_size = file_size;
	}
	public Timestamp getReg_date() {
		return reg_date;
	}
	public void setReg_date(Timestamp reg_date) {
		this.reg_date = reg_date;
	}
	public Timestamp getMod_date() {
		return mod_date;
	}
	public void setMod_date(Timestamp mod_date) {
		this.mod_date = mod_date;
	}
	public String getDel_flag() {
		return del_flag;
	}
	public void setDel_flag(String del_flag) {
		this.del_flag = del_flag;
	}

} //FileVO
