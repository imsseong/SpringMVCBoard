package com.seongim.mvc_board.service;

import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.seongim.mvc_board.domain.BoardVO;
import com.seongim.mvc_board.domain.ReplyVO;
import com.seongim.mvc_board.persistence.BoardDAO;
import com.seongim.mvc_board.persistence.ReplyDAO;

@Service
public class ReplyServiceImpl implements ReplyService {

private static final Logger logger = LoggerFactory.getLogger(BoardServiceImpl.class);
	
	@Inject
	ReplyDAO replyDAO;

	@Override
	public void insertReply(ReplyVO replyVO) throws Exception {
		replyDAO.insertReply(replyVO);		
	}

	@Override
	public List<Map<String,Object>> getReplyList(BoardVO boardVO) throws Exception {
		return replyDAO.getReplyList(boardVO);
	}

	@Override
	public void deleteReply(ReplyVO replyVO) throws Exception {
		replyDAO.deleteReply(replyVO);
	}

	@Override
	public void deleteReplyAll(ReplyVO replyVO) throws Exception {
		replyDAO.deleteReplyAll(replyVO);
	}
	
} //ReplyServiceImpl
