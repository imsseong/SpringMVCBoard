package com.seongim.mvc_board.service;

import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

import com.seongim.mvc_board.domain.BoardVO;
import com.seongim.mvc_board.domain.FileVO;
import com.seongim.mvc_board.domain.PagingVO;

public interface BoardService {
	/** �Խ��� ��� */
	public void insertBoard(BoardVO boardVO) throws Exception;
	
	/** �Խ��� ��� ��ȸ */
	public List<Map<String, Object>> getBoardList(PagingVO pagingVO) throws Exception;
	
	/** �Խ��� �� ��ȸ */
	public Map<String, Object> getBoardDetail(BoardVO boardVO) throws Exception;
	
	/** �Խ��� ���� */
	public void updateBoard(BoardVO boardVO) throws Exception;
	
	/** �Խ��� ���� */
	public void deleteBoard(BoardVO boardVO) throws Exception;

	public int getBoardCount() throws Exception;
	
	public int getBoardId(BoardVO boardVO) throws Exception;
	
	public void uploadFile(int boardId, String originFileName, String saveFileName, long fileSize) throws Exception;
	
	public List<Map<String, Object>> getFileList(BoardVO boardVO) throws Exception;
	
	public void deleteFile(String saveFileName) throws Exception;
	
} //boardService
