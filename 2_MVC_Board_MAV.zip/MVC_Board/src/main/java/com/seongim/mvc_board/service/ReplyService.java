package com.seongim.mvc_board.service;

import java.util.List;
import java.util.Map;

import com.seongim.mvc_board.domain.BoardVO;
import com.seongim.mvc_board.domain.ReplyVO;

public interface ReplyService {

	/** ��� ��� */
	public void insertReply(ReplyVO replyVO) throws Exception;
	
	/** ��� ��ȸ */
	public List<Map<String,Object>> getReplyList(BoardVO boardVO) throws Exception;
	
	/** ��� ���� */
	public void deleteReply(ReplyVO replyVO) throws Exception;
	
	/** ��� ��� ���� */
	public void deleteReplyAll(ReplyVO replyVO) throws Exception;
	
} //ReplyService