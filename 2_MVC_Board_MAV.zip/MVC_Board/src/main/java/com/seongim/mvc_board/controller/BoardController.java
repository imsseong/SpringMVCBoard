package com.seongim.mvc_board.controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.URLEncoder;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.annotation.Resource;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.seongim.mvc_board.domain.BoardVO;
import com.seongim.mvc_board.domain.FileVO;
import com.seongim.mvc_board.domain.PageMakerVO;
import com.seongim.mvc_board.domain.PagingVO;
import com.seongim.mvc_board.domain.ReplyVO;
import com.seongim.mvc_board.service.BoardService;
import com.seongim.mvc_board.service.ReplyService;

@Controller
@RequestMapping("/board")
public class BoardController {
	
	private static final Logger logger = LoggerFactory.getLogger(BoardController.class);
	
	@Inject
	private BoardService boardService;
	@Inject
	private ReplyService replyService;

	@Resource(name="uploadPath")
	private String uploadPath;
	
	/** �Խ��� ��� */
	@RequestMapping("/boardList")
	public ModelAndView boardList(PagingVO pagingVO) throws Exception {
		logger.info("BoardList");
		
		ModelAndView mav = new ModelAndView("/board/boardList");
        
		PageMakerVO pageMaker = new PageMakerVO();
		pageMaker.setPagingVO(pagingVO);
		pageMaker.setTotalCount(boardService.getBoardCount());

        List<Map<String,Object>> list = boardService.getBoardList(pagingVO);
        mav.addObject("list", list);
        mav.addObject("pageMaker", pageMaker);
        mav.addObject("pagingVO", pagingVO);
        return mav;
	}
	
	/** �Խ��� ��� ������ */
	@RequestMapping("/boardWrite")
    public void boardWrite() throws Exception {}

	/** �Խ��� ��� */
	@RequestMapping("/boardWritePost")
    public ModelAndView boardWritePost(BoardVO boardVO, MultipartHttpServletRequest request) throws Exception {
        ModelAndView mav = new ModelAndView("redirect:/board/boardList");
        
        boardService.insertBoard(boardVO);
        
        // �Ѿ�� ������ ����Ʈ�� ����
        List<MultipartFile> fileList = request.getFiles("files");
        

        if(request.getFiles("files").get(0).getSize() != 0) {
        	fileList = request.getFiles("files");
        }

        uploadPath = "C:\\Tomcat\\webapps\\upload";
        File fileDir = new File(uploadPath);

        if (!fileDir.isDirectory()) {
        	fileDir.mkdirs();
        }
        
        if ( fileList != null && fileList.size() > 0 ) {
        	long time = System.currentTimeMillis();
        	
        	for (MultipartFile mf : fileList) {
	        	if ( !mf.isEmpty() ) {
		        	String originFileName = mf.getOriginalFilename();
		            String originalFileExtension = originFileName.substring(originFileName.lastIndexOf(".")); 
		            String saveFileName = String.format("%d_%s", time, originFileName);      	
		            long fileSize = mf.getSize();

			        try { // ���ϻ��� 
			        	mf.transferTo(new File(uploadPath, saveFileName));
			        	
			        	int boardId = boardService.getBoardId(boardVO);
			            
			            boardService.uploadFile(boardId, originFileName,saveFileName, fileSize);
			        } catch (Exception e) {
			        	e.printStackTrace();
			        }
	        	} //if
        	} //for
        } else {
        	 System.out.println("ERROR");
        }
        
        return mav;
    }
	
	/** �Խ��� �� */
	@RequestMapping("/boardDetail")
	public ModelAndView boardDetail(BoardVO boardVO, ReplyVO replyVO) throws Exception {
		ModelAndView mav = new ModelAndView("/board/boardDetail");
		
	    Map<String, Object> detail = boardService.getBoardDetail(boardVO);
	    List<Map<String,Object>> file = boardService.getFileList(boardVO);
	    List<Map<String,Object>> reply = replyService.getReplyList(boardVO);

	    mav.addObject("detail",detail);
	    mav.addObject("file", file);
	    mav.addObject("reply", reply);
	    
	    return mav;
	}

	/** �Խ��� ���� ������*/
	@RequestMapping("/boardUpdate")
	public ModelAndView boardUpdate(BoardVO boardVO) throws Exception {
		ModelAndView mav = new ModelAndView("/board/boardUpdate");
	    
		Map<String, Object> detail = boardService.getBoardDetail(boardVO);
		List<Map<String,Object>> file = boardService.getFileList(boardVO);
		
	    mav.addObject("detail",detail);
	    mav.addObject("file", file);

	    return mav;
	}
	
	/** �Խ��� ���� */
	@RequestMapping("/boardUpdatePost")
	public ModelAndView boardUpdatePost(BoardVO boardVO, MultipartHttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView("redirect:/board/boardDetail");
		
		mav.addObject("id",boardVO.getId());
		boardService.updateBoard(boardVO);
		
		// �Ѿ�� ������ ����Ʈ�� ����
        List<MultipartFile> fileList = request.getFiles("files");
        

        if(request.getFiles("files").get(0).getSize() != 0) {
        	fileList = request.getFiles("files");
        }

        uploadPath = "C:\\Tomcat\\webapps\\upload";
        File fileDir = new File(uploadPath);

        if (!fileDir.isDirectory()) {
        	fileDir.mkdirs();
        }
        
        if ( fileList != null && fileList.size() > 0 ) {
        	long time = System.currentTimeMillis();
        	
        	for (MultipartFile mf : fileList) {
	        	if ( !mf.isEmpty() ) {
		        	String originFileName = mf.getOriginalFilename();
		            String originalFileExtension = originFileName.substring(originFileName.lastIndexOf(".")); 
		            String saveFileName = String.format("%d_%s", time, originFileName);      	
		            long fileSize = mf.getSize();

			        try { // ���ϻ��� 
			        	mf.transferTo(new File(uploadPath, saveFileName));
			        	
			        	int boardId = boardService.getBoardId(boardVO);
			            
			            boardService.uploadFile(boardId, originFileName,saveFileName, fileSize);
			        } catch (Exception e) {
			        	e.printStackTrace();
			        }
	        	} //if
        	} //for
        } else {
        	 System.out.println("ERROR");
        }
        
     
	    return mav;
	}
	
	/** �Խ��� ���� */
	@RequestMapping("/boardDelete")
	public ModelAndView boardDelete(BoardVO boardVO, ReplyVO replyVO) throws Exception {
		ModelAndView mav = new ModelAndView("redirect:/board/boardList");
        
		//replyService.deleteReplyAll(replyVO);
		boardService.deleteBoard(boardVO);
		
		return mav;
	}
	
	/** ��� ��� */
	@RequestMapping("/replyWrite")
    public ModelAndView replyWrite(ReplyVO replyVO, HttpServletRequest request) throws Exception {
		System.out.println(request.getParameter("reply_writer"));
		System.out.println(request.getParameter("reply_content"));
		System.out.println(request.getParameter("board_id"));
        ModelAndView mav = new ModelAndView("redirect:/board/boardDetail?id=" + request.getParameter("board_id"));
        
        replyService.insertReply(replyVO);
        
        return mav;
    }
	
	/** ��� ���� */
	@RequestMapping("/replyDelete")
	public ModelAndView replyDelete(ReplyVO replyVO, HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView("redirect:/board/boardDetail?id=" + request.getParameter("reply_id"));
		System.out.println(request.getParameter("reply_id"));
		replyService.deleteReply(replyVO);
        
		return mav;
	}
	
	@RequestMapping("/downloadFile")
	public ModelAndView downloadFile(FileVO fileVO, HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView("redirect:/board/boardDetail");
		System.out.print("request : " + request);
		System.out.print("request : " + request.getParameter("saveFileName"));
		
		String saveFileName = request.getParameter("saveFileName");
		String originFileName = request.getParameter("originFileName");
		
				File file = new File("C:\\Tomcat\\webapps\\upload", saveFileName);
		
		BufferedInputStream in = new BufferedInputStream(new FileInputStream(file));
		 //User-Agent : � �ü����  � �������� ����( Ȩ������ )�� �����ϴ��� Ȯ����
		 String header = request.getHeader("User-Agent");
		 String fileName;
		 
		 if ((header.contains("MSIE")) || (header.contains("Trident")) || (header.contains("Edge"))) {
		        //���ͳ� �ͽ��÷η� 10���� ����, 11����, �������� ���ڵ� 
		        fileName = URLEncoder.encode(originFileName, "UTF-8");
		 } else {
		        //������ ���������� ���ڵ�
		        fileName = new String(originFileName.getBytes("UTF-8"), "iso-8859-1");
		 }

		 //������ �𸣴� ����÷�ο� contentType
		 response.setContentType("application/octet-stream");
		 //�ٿ�ε�� �ٿ�ε�� �����̸�
		 response.setHeader("Content-Disposition", "attachment; filename=\""+ fileName + "\"");
		 //���Ϻ���
		 FileCopyUtils.copy(in, response.getOutputStream());
		 in.close();
		 response.getOutputStream().flush();
		 response.getOutputStream().close();  
		 
		 return mav;
	}
	
	@RequestMapping("/deleteFile")
	public ModelAndView deleteFile(HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView("redirect:/board/boardUpdate?id=" + request.getParameter("id"));
		System.out.println("saveFileName : " + request.getParameter("saveFileName"));
		//replyService.deleteReplyAll(replyVO);
		boardService.deleteFile(request.getParameter("saveFileName"));
		
		return mav;
	}
	

} //BoardController
