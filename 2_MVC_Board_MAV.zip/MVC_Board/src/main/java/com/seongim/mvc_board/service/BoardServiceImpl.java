package com.seongim.mvc_board.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.seongim.mvc_board.controller.BoardController;
import com.seongim.mvc_board.domain.BoardVO;
import com.seongim.mvc_board.domain.FileVO;
import com.seongim.mvc_board.domain.PagingVO;
import com.seongim.mvc_board.persistence.BoardDAO;

@Service
public class BoardServiceImpl implements BoardService {

	private static final Logger logger = LoggerFactory.getLogger(BoardServiceImpl.class);
	
	@Inject
	BoardDAO boardDAO;
	
	@Override
	public void insertBoard(BoardVO boardVO) throws Exception {
	    boardDAO.insertBoard(boardVO);
	}

	@Override
	public List<Map<String, Object>> getBoardList(PagingVO pagingVO) throws Exception {
		return boardDAO.getBoardList(pagingVO);
	}

	@Override
	public Map<String, Object> getBoardDetail(BoardVO boardVO) throws Exception {
		boardDAO.updateHit(boardVO);
		return boardDAO.getBoardDetail(boardVO);
		
	}

	@Override
	public void updateBoard(BoardVO boardVO) throws Exception {
		boardDAO.updateBoard(boardVO);
	}

	@Override
	public void deleteBoard(BoardVO boardVO) throws Exception {
		boardDAO.deleteBoard(boardVO);
	}
	
	@Override
	public int getBoardCount() throws Exception {
		return boardDAO.getBoardCount();
	}
	
	@Override
	public int getBoardId(BoardVO boardVO) throws Exception {
		return boardDAO.getBoardId(boardVO);
	}
	
	@Override
	public void uploadFile(int boardId, String originFileName, String saveFileName, long fileSize) throws Exception {
		HashMap<String, Object> hm = new HashMap<>();
		System.out.println("boardId = "+boardId);
		hm.put("board_id", boardId);
	    hm.put("org_file_name", originFileName);
	    hm.put("save_file_name", saveFileName);
	    hm.put("file_size", fileSize);
	     
	    boardDAO.uploadFile(hm);
	}

	@Override
	public List<Map<String, Object>> getFileList(BoardVO boardVO) throws Exception {
		return boardDAO.getFileList(boardVO);
	}
	
	@Override
	public void deleteFile(String saveFileName) throws Exception {
		boardDAO.deleteFile(saveFileName);
	}
	
} //boardServiceImpl
